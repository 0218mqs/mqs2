<template>
  <div class="addContacts">
    <div class="addContacts_tit">
      <span><</span>
      收货人
      <span></span>
    </div>
    <div class="addContacts_info">
      <div class="input">
        <input type="text" placeholder="收货人姓名">
      </div>
      <div class="input">
        <input type="text" placeholder="手机号">
      </div>

      <div class="input flex_box">
        <div class="dropDown half">
          <p>北京</p><span>﹀</span>
          <ul class="">
            <li>1</li>
            <li>2</li>
            <li>3</li>
          </ul>
        </div>
        <div class="dropDown half">
          <p>北京</p><span>﹀</span>
          <ul class="">
            <li>1</li>
            <li>2</li>
            <li>3</li>
          </ul>
        </div>
      </div>
      <div class="input">
        <div class="dropDown">
          <p>海淀</p><span>﹀</span>
          <ul class="">
            <li>1</li>
            <li>2</li>
            <li>3</li>
          </ul>
        </div>
      </div>
      <div class="input">
        <input type="text" placeholder="详情地址">
      </div>
    </div>
    <div class="state">
      <div class="btns btn_bg" >✔</div> 设为默认地址
    </div>
    <div class="add_address">
      <button type="button">保存</button>
    </div>
  </div>
</template>

<script>

export default {
  name: 'addContacts',
  data () {
    return {

    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>

.addContacts{
	width:100%;
	height:100%;
  display: flex;
  background: #f3f3f3;
  flex-direction: column;
}
.addContacts_tit{
  width:100%;
  height:0.88rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding:0 0.3rem;
  font-size:0.34rem;
  background: #fff;
  border-bottom:solid 0.01rem #ccc;
  flex-shrink: 0;
}
.addContacts_tit span{
  font-family: "宋体";
  font-weight: bold;
  font-size:0.38rem;
  display: block;
  width:0.3rem;
}
.addContacts_info{
  width:100%;
  padding:0 0.3rem;
}
.input{
  width:100%;
  margin-top: 0.3rem;
  height:0.9rem;
}
.input input{
  background: #fff;
  width:100%;
  height: 100%;
  display: block;
  border-radius: 0.1rem;
  padding:0 0.2rem;
}
.input input::-webkit-input-placeholder{
  color:#999999;
  font-size:0.32rem;
}
.flex_box{
  display: flex;
  justify-content: space-between;
}
.dropDown{
  position: relative;
  font-size:0.32rem;
  background: #fff;
  color:#333;
  border-radius: 0.1rem;
}
.dropDown ul{
  position: absolute;
  top:0.9rem;
  left:0;
  display: none;
  z-index: 999;
  background: #fff;
  border:solid 0.01rem #e5e5e5;
  border-radius: 0.2rem ;
  width:100%;
}
.dropDown ul li{
  width:100%;
  line-height: 0.8rem;
  border-bottom:solid 0.01rem #e5e5e5;
  padding:0 0.2rem;
}
.dropDown ul li:hover{
  background: #ccc;
  color: #fff;
}
.dropDown ul.show{
  display: block;
}
.dropDown p{
  width:100%;
  height:100%;
  line-height: 0.9rem;
  padding:0 0.2rem;
}
.dropDown span{
  position: absolute;
  right:0.2rem;
  top:0;
  line-height: 1rem;
  font-weight: bold;
  font-size:0.3rem;
  font-family: "宋体";
}
.flex_box .half{
  width:3rem;
  height:100%;
}
.state{
  width:100%;
  display: flex;
  height:1rem;
  padding:0 0.3rem;
  align-items: center;
  font-size:.032rem;
  color:#666;
}
.btns{
  width:0.45rem;
  height:0.45rem;
  font-size:0.3rem;
  line-height: 0.42rem;
  border:solid 0.02rem #cccccc;
  border-radius: 50%;
  overflow: hidden;
  text-align: center;
  color:#fff;
  margin-right:0.12rem;
}
.btn_bg{
  background: #fc4141;
}
.add_address{
  width:100%;
  height:1.8rem;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-shrink: 0;
}
.add_address button{
  width:4.6rem;
  height:1.02rem;
  border-radius: 0.51rem;
  background: #fc4141;
  font-size: 0.34rem;
  color:#fff;
  display: flex;
  justify-content: center;
  align-items: center;
  box-shadow: 2px 2px 3px rgba(252,65,65,0.6);
}
</style>
